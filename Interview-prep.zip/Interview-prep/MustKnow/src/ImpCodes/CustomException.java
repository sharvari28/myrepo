package ImpCodes;

public class CustomException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	public  CustomException(){  
		    System.out.println("InvalidAgeException");
		 }  
	
	
	public static void main(String[] args) {
		
		int age = -2;
		
		if(age<0){
			try {
				throw new CustomException();
			} catch (CustomException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			}
			
		}else{
			System.out.println("Done");
		}
		
		System.out.println("out");

	}
		
	}
