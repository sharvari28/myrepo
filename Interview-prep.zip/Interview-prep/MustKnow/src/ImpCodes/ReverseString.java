package ImpCodes;

public class ReverseString {

	public static void main(String[] args) {

		String original="Sharvari";
		String reverse = "";
		
		int len=original.length();
		for(int i = len - 1 ; i >= 0 ; i--){
			reverse = reverse + original.charAt(i);

		    
		}
		System.out.println(len);
		System.out.println(len-1);
		
		System.out.println("Original of the string: " + original);
		System.out.println("Reverse of the string: " + reverse);
	}

}
