package ImpCodes;


public class removeSpacesFromString 
{ 
    public static void main(String args[]) 
    { 
        String str1 = "  Hello World  "; 
        System.out.println(str1); 
        System.out.println(str1.trim()); 
  
        String str2 = "      Hey  there    Joey!!!      "; 
        System.out.println(str2); 
        System.out.println(str2.split("//s"));
        System.out.println(str2.trim()); 
    } 
} 
