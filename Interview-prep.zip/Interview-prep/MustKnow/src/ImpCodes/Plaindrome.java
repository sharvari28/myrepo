package ImpCodes;

//import for Scanner and other utility classes
import java.util.*;


class Plaindrome {
  public static void main(String args[] ) throws Exception {
      //Scanner
      Scanner s = new Scanner(System.in);
      String name = s.nextLine();                 

      String reverse = "";
      int len=name.length();

      for (int i=len-1;i>=0;i--){
          reverse=reverse+name.charAt(i);
      } 
      
      System.out.println("name" +name);
      System.out.println("reverse" +reverse);
      if(reverse.equalsIgnoreCase(name)){
    	  System.out.println("Palindrome");
      }else{
    	  System.out.println("Not Palindrome");
      }

      // Write your code here

  }
}

