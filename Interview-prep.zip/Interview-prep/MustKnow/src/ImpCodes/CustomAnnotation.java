package ImpCodes;


@interface sheru{
	
}

@interface sheru1{
	int value();
}


public class CustomAnnotation {

	@sheru
	@sheru1(value = 0)
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
