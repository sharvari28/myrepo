package basicClassObjectProgams;

class Student1{
	int id=102;
	String name="ava";
	
	void insertinto(int id,String name){
		this.id=id;
		this.name=name;
			}
	
	void displayInformation(){
		System.out.println(id+" "+name);
		}  
	} 

public class ObjectInitbyMethod {

	public static void main(String[] args) {

		Student1 s1 = new Student1();
		s1.insertinto(101, "Sheru");
		s1.displayInformation();
	}

}
