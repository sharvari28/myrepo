package basicClassObjectProgams;

public class A {

	public static void main(String[] args) {
		//System.out.println('j'+'a');
		
		/*Integer num1=100;
		Integer num2=100;
		
		if(num1==num2){
			System.out.println("equal");
		}else if(num1!=num2){
			System.out.println("not equla");
		}*/
		
		Integer a = null;
        @SuppressWarnings("null")
		int b = a;
        System.out.println(b);
		
	}

}
