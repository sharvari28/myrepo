package basicClassObjectProgams;

class A1 {
    public A1() {
        System.out.print("A");
    }
}

class B extends A1 {
    public B() {
    	super();
        System.out.print("B");
        
    }
}

public class Try {
    public static void main(String[] args) {
        new B();
    }
}
