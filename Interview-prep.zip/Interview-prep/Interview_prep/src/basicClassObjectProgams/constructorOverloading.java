package basicClassObjectProgams;

class Student4{
	int id;
	String name;
	int salary;
	
	Student4(int i,String n){
		id=i;
		name=n;
		
	}
	
	Student4(int i,String n,int s){
		id=i;
		name=n;
		salary=s;
		
	}
	
	void display(){
		System.out.println(id+name+salary);
	}
}
public class constructorOverloading {

	public static void main(String[] args) {
		Student4 s=new Student4(101,"sheru");
		Student4 s1=new Student4(101,"sheru",1000);
		s.display();s1.display();
		

	}

}
