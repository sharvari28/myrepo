package basicClassObjectProgams;


class Student3{
	int id;
	String name;
	
	Student3(int i,String n){
		id=i;
		name=n;
		
	}
	
	void display(){
		System.out.println(id+name);
	}
}
public class parameterizedConstructor {

	public static void main(String[] args) {
		Student3 s3=new Student3(101,"sheru");
        s3.display();
	}

}
