package basicClassObjectProgams;

class Studentabc{
	int id;
	String name;
}

public class ObjectInitbyReference {

	public static void main(String[] args) {
		
		Studentabc s1 = new Studentabc();
		s1.id=101;
		s1.name="Sheru";

		System.out.println("Id is "+s1.id);
		System.out.println("Name is "+s1.name);
		
	}

}
