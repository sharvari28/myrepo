package basicClassObjectProgams;


class students{
	int id;
	String name;
	static String college="BVP";
	
	students(int i,String n){
		id=i;
		name=n;
		
	}
	
	void studentmethod(){
		 college="bvpit";
	}
	void display(){
		System.out.println(id + name + college);
	}
}
public class staticMethodTest {

	public static void main(String[] args) {
		
		students s1= new students(111,"qwerty");
		students s2=new students(222,"asdf");
		students s3=new students(333,"zxcv");
		s1.studentmethod();
		s1.display();s2.display();s3.display();
		
		

	}

}
