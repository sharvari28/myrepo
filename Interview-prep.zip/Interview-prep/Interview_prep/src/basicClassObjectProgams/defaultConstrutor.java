package basicClassObjectProgams;

class Student2{
	int id;
	String name;
	
	Student2(){
		System.out.println("Default constructor for student2 class");
	}
}
public class defaultConstrutor {

	public static void main(String[] args) {
		Student2 s2=new Student2();
	}

}
