class Parent{
	void add(){
		System.out.println("Parent");
	}
}

class Child1 extends Parent{
	void add(){
		System.out.println("Child1");
	}
	
	void Multiply(){
		System.out.println("Multiply1");
	}
}

class Child2 extends Parent{
	void add(){
		System.out.println("Child2");
	}
	void Multiply(){
		System.out.println("Multiply2");
	}
}



public class testInterface implements markerInterface {

	public static void main(String[] args) {
		Parent p1=new Child1();
		Parent p2=new Child2();
		
		p1.add();
		p2.add();
		((Child1) p1).Multiply();
		
		
		
		
	}

}
