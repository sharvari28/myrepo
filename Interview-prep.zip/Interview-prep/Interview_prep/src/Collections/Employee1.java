package Collections;

public class Employee1 {

	private Integer id;
	private String name;
	
	
	public Employee1(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
	@Override
	public boolean equals(Object obj){
		if(obj instanceof Employee1){
			Employee1 e = new Employee1(id, name);
			if(id.equals(e.id))
				return true;
			else
			    return false;
		}
		return false;
	}
	
	@Override
	public int hashCode(){
		return id;
		
	}
	
	@Override
	public String toString() {
		return "Employee1 [id=" + id + ", name=" + name + "]";
	}
	
	
}
