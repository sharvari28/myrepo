package Collections;


import java.util.*;  
class HashSetTest{  
	
	
 public static void main(String args[]){  
  //Creating HashSet and adding elements  
    Set<Employee1> set=new HashSet<Employee1>();  
           set.add(new Employee1(100, "Sharvari"));  
           set.add(new Employee1(100, "Sharvari"));
           set.add(new Employee1(100, "Sheru"));
           set.add(new Employee1(100, "Avanti"));
           
           
           Iterator<Employee1> i=set.iterator();  
           while(i.hasNext())  
           {  
           System.out.println(i.next());  
           }  
 }  
}  