package Collections;

  class Laptop {

	private Integer Model;
	private String barnd;
	
	public Laptop(Integer model, String barnd) {
		super();
		Model = model;
		this.barnd = barnd;
	}

	
	public Integer getModel() {
		return Model;
	}


	public void setModel(Integer model) {
		Model = model;
	}


	public String getBarnd() {
		return barnd;
	}


	public void setBarnd(String barnd) {
		this.barnd = barnd;
	}


	@Override
	public String toString() {
		return "Laptop [Model=" + Model + ", barnd=" + barnd + "]";
	}

	

	}

	

	
	
	
	
	


