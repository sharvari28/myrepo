package Collections;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentHashmapThreadTest extends Thread{
	
	static HashMap m = new HashMap();
	
	public void run(){
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
			System.out.println("Child thread updating map");
			m.put(101,"sheru");
		}
	}
	
	public static void main(String[] args) throws InterruptedException {
		m.put(102,"sharvari");
		m.put(103,"tatwawadi");
		
		Thread t1 = new ConcurrentHashmapThreadTest();
		t1.run();
		Set s1=m.keySet();
		Iterator i =s1.iterator();
		
		while(i.hasNext()){
			Integer i1 = (Integer) i.next();
			System.out.println("Main thread is iterating map and current entry is" +i1+ ":" +m.get(i1));
			Thread.sleep(1000);
		}
		
		System.out.println(m);

	}

}
