package Collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class LaptopCompare {

	public static void main(String[] args) {
		List<Laptop> laps=new ArrayList<Laptop>();
		laps.add(new Laptop(20,"dell"));
		laps.add(new Laptop(200,"hp"));
		laps.add(new Laptop(230,"lenovo"));
		laps.add(new Laptop(70,"sony"));
		
		/*Comparator c = new Comparator(){

			public int compare(Laptop l1,Laptop l2) {
				if(l1.getModel()==l2.getModel())
				return 1;
				else return -1;
			}

		

					
		};
			
		Collections.sort(laps,c);*/
		System.out.println(laps);

	}

	}
