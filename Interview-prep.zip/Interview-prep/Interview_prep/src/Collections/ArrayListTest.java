package Collections;

import java.util.*;  
public class ArrayListTest{  
 public static void main(String args[]){  
	 
  ArrayList<String> list=new ArrayList<String>();//Creating arraylist  
  list.add("Mango");//Adding object in arraylist    
  list.add("Apple");    
  list.add("Banana");    
  list.add("Grapes");  
  list.add("Grapes");
  list.add("Banana");
  //Traversing list through for-each loop  
  /*for(String fruit:list)  {
	  System.out.println(fruit);
  }*/
  
  System.out.println("element at 1st index is" +list.get(1));
  list.add(1, "Cherry");
  
  //Collections.sort(list);
  System.out.println(list);
  /*for(String fruit:list)  {
	  System.out.println(fruit);
  }*/
  
      
  
 }  
}  