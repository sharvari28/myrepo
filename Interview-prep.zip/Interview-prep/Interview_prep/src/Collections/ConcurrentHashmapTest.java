package Collections;

import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentHashmapTest {

	public static void main(String[] args) {
		
		
		ConcurrentHashMap m = new ConcurrentHashMap();
		m.put(101,"A");
		m.put(102,"b");
		m.putIfAbsent(103, "A");
		m.putIfAbsent(101, "d");
		m.replace(102, "b", "x");
		
		System.out.println(m);
		
	}
		
		
	}

