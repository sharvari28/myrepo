package Collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ArrayCompare {
	
	
	
	public static void main(String[] args) {
		String s = "techm";
		
		char[] c1 = s.toCharArray();
		System.out.println(c1);
		
		char[] c = new char[5];
		c[0] = 't';
		c[1] = 'e';
		c[2] = 'c';
		c[3] = 'm';
		c[4] = 'h';
		System.out.println(c);
		
		if(Arrays.equals(c, c1)){
			System.out.println("Both are equal");
		}else{
			System.out.println("Both are not equal");
			
			
			for(int i=0;i<c1.length;i++){
				for(int j=0;j<c.length;j++){
					if (c[i]!=c1[j]){
						char temp = c[i]; 
		               c[i] = c[i+1]; 
		                c[i+1] = temp;
					}
				}
				
			}
			
			System.out.println(c);
		}
			
	}

}
