
public interface markerInterface {

}
