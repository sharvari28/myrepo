/* 
 * Save this in a file called Main.java and compile it. To test it 
 * create the file `input.txt` in the workspace / Working Directory
 * (For Eclipse/VisualStudio, by default this is the top level project folder)
 */

/* Do not add a package declaration */
import java.util.*;
import java.io.*;

/* DO NOT CHANGE ANYTHING ABOVE THIS LINE */
/* You may add any imports here, if you wish, but only from the 
   standard library */

/* Do not add a namespace declaration */
public class Main {
    public static Map<String,Integer> processData(ArrayList<String> array) {
    	 int arr1[]= new int[10];
    	    int arr2[]= new int[10];
    	    int count=0;
    	    int a=0,b=0;
    	    Map<String,Integer> retVal = new HashMap<String,Integer>();
    	   
    	for(String str : array){
    		String[] string = str.split(",");
    		
    		 if(string[2].trim().equals("Testing"))
             {
                  arr1[count]=(int)Integer.parseInt(string[0].trim());
                 if(a<=arr1[count])
                     a=arr1[count];
             }
    		 
    		 if(string[2].trim().equals("Engineering"))
             {
                  arr2[count]=(int)Integer.parseInt(string[0].trim());
                 if(b<=arr2[count])
                     b=arr2[count];
             }
     }
    	
    	for(String str : array){
    		String[] string = str.split(",");
            if(a==(int)Integer.parseInt(string[0].trim())) {

                Integer i=(Integer)Integer.parseInt(string[3].trim());
                retVal.put("Testing",i);

            }
            if(b==(int)Integer.parseInt(string[0].trim())) {
                Integer i=(Integer)Integer.parseInt(string[3].trim());
                retVal.put("Engineering",i);

            }

        }

        return retVal;
}
    public static void main (String[] args) {
        ArrayList<String> inputData = new ArrayList<String>();
        String line;
        try {
            Scanner in = new Scanner(new BufferedReader(new FileReader("C:/Interview-prep/Interview_prep/src/input.txt")));
            while(in.hasNextLine())
                inputData.add(in.nextLine());
            Map<String,Integer> retVal = processData(inputData);
            PrintWriter output = new PrintWriter(new BufferedWriter(new FileWriter("C:/Interview-prep/Interview_prep/src/output.txt")));
            for(Map.Entry<String,Integer> e: retVal.entrySet())
                output.println(e.getKey() + ": " + e.getValue());
            output.close();
        } catch (IOException e) {
        	e.printStackTrace();
            System.out.println("IO error in input.txt or output.txt");
            
            Integer a = null;
            int b = a;
            System.out.println(b);
        }
    }
}
