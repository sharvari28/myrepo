import java.util.Scanner;



class TestClass1 {
    public static void main(String args[] ) throws Exception {
        
        Scanner s = new Scanner(System.in);
        Integer n=s.nextInt();
        
        Scanner s1 = new Scanner(System.in);
        String name = s1.nextLine();       
        
        System.out.println(n*2);
        System.out.println(name);
           }
}
