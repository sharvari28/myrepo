class A{
	void add() throws ArithmeticException{
		System.out.println("AE");
	}
}


class B extends A{
	void add() throws NumberFormatException{
		System.out.println("NFE");
	}
}
public class xceptionHandling {

	public static void main(String[] args) {
		B b = new B();
		b.add();

	}

}
