class X{
	
}

class Y extends X{
	
	
	public  void stop(){
		System.out.println("Y Stopped");
	}
}


public class testInheritance {
public static void main(String[] args) {
	X x = new X();
	
	Y y = new Y();
	
	y.stop();
}
}
