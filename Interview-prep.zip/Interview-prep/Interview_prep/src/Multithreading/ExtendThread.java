package Multithreading;

class Hi extends Thread{
	
	public void run(){
		for(int i=0;i<5;i++){
			System.out.println("Hi");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
}

class Hello extends Thread{
	
	public void run(){
		for(int i=0;i<5;i++){
			System.out.println("Hello");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
}
public class ExtendThread {

	public static void main(String[] args) throws InterruptedException {
		Thread obj1= new Hi();
		Thread obj2=new Hello();
		
		obj1.start();
		Thread.sleep(100);
		obj2.start();
		

	}

}
