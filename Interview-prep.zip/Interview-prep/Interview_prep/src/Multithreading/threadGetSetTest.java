package Multithreading;

public class threadGetSetTest extends Thread {
	
	public void run(){
		System.out.println(Thread.currentThread().getId());
		System.out.println(Thread.currentThread().getName());
		System.out.println(Thread.currentThread().getPriority());
		
		/*for (int i = 0; i < 5; i++) {
			try {
				Thread.sleep(1500);
			} catch (InterruptedException e) {
				e.printStackTrace();

			}
			System.out.println(i);
		}*/
	}

	public static void main(String[] args) {

		threadGetSetTest t1=new threadGetSetTest();
		threadGetSetTest t2=new threadGetSetTest();
		threadGetSetTest t3=new threadGetSetTest();
		
		t1.setPriority(MAX_PRIORITY);
		t2.setPriority(MIN_PRIORITY);
		t3.setPriority(NORM_PRIORITY);
		t1.start();
		t2.start();
		t3.start();
		
		
	}

}
