package Multithreading;


public class TestShutdown extends Thread{
	
	public void run(){  
        System.out.println("shut down hook task completed..");  
    }  


	public static void main(String[] args) {
		TestShutdown t1=new TestShutdown();
		Runtime r=Runtime.getRuntime(); 
		r.addShutdownHook(t1);
		
		
		System.out.println("Now main sleeping... press ctrl+c to exit");  
		try{Thread.sleep(3000);}catch (Exception e) {}  
		r.removeShutdownHook(t1);
		 
	}

}
