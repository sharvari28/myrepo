package Multithreading;

class MyThread extends Thread {

	
	int a[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
	
	public void run() {
		
		for (int i=0;i<a.length;i++) {
			a[i] = a[i] * 2;
			System.out.println(a[i]);
			
		}
	}

}

public class arrayTest {

	public static void main(String[] args) {
		
    Thread t1 = new MyThread();
    t1.start();

	}

}
