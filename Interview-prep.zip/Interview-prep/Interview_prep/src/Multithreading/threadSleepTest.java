package Multithreading;

public class threadSleepTest extends Thread{

	public synchronized void run(){
		for(int i=0;i<5;i++){
			try {
				Thread.sleep(1500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}
			System.out.println(i);
		}
	}
	public static void main(String[] args) throws InterruptedException {
		
		threadSleepTest t1=new threadSleepTest();
		threadSleepTest t2=new threadSleepTest();
		threadSleepTest t3=new threadSleepTest();
		
		t1.start();
		//t1.join();
		//t1.run();
		t2.start();
		t3.start();

	}

}
