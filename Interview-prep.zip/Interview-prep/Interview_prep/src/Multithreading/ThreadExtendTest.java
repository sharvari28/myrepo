/*package Multithreading;


class mythread extends Thread{
	public void run(){
		System.out.println("Parent class");
	}
	
}

public class ThreadExtendTest extends mythread{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
*/