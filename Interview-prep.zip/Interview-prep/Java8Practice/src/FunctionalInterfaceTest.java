
@FunctionalInterface
interface A{
	
	public void show();
}

public class FunctionalInterfaceTest {
	
	public static void main(String[] args) {
		
	
	
 A a = () -> System.out.println("In show");
	
 a.show();
}
}