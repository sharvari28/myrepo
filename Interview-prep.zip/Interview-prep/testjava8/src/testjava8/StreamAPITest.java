package testjava8;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;



public class StreamAPITest {
	
	public static void main(String[] args) {
		
		ArrayList<Integer> list=new ArrayList<Integer>();
		list.add(2);
		list.add(3);
		list.add(10);
		list.add(15);
		list.add(27);
		
		for(int i=0;i<5;i++){
			System.out.println(list.get(i));
		}
		
		Iterator i = list.iterator();
		while(i.hasNext()){
			
			System.out.println(i.next());
		}
		
	list.forEach(i -> System.out.println(i));
	}

}
