package testjava8;

interface A{
	
	void show();
}

public class LambdaTest {
	
	public static void main(String[] args) {
		
	
	
/* A a =() -> System.out.println("In show");
	
 a.show();*/
}
}