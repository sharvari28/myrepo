package builderDesignPatternTest;

public class Shop {

	public static void main(String[] args) {
		
		Phone p = new PhoneBuilder().setOS("Android").setBattery(5000).getPhone();
	
		System.out.println(p);
	}

}
