package builderDesignPatternTest;

public class Phone {

	private String OS;
	private int RAM;
	private String brand;
	private double screenSize;
	private int battery;
	
	
	public Phone(String oS, int rAM, String brand, double screenSize,
			int battery) {
		super();
		OS = oS;
		RAM = rAM;
		this.brand = brand;
		this.screenSize = screenSize;
		this.battery = battery;
	}


	@Override
	public String toString() {
		return "Phone [OS=" + OS + ", RAM=" + RAM + ", brand=" + brand
				+ ", screenSize=" + screenSize + ", battery=" + battery + "]";
	}
	
	
	
}
