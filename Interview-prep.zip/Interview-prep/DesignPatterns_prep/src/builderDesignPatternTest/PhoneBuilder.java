package builderDesignPatternTest;

public class PhoneBuilder {
	
	private String OS;
	private int RAM;
	private String brand;
	private double screenSize;
	private int battery;
	
	
	public PhoneBuilder setOS(String oS) {
		this.OS = oS;
		return this;
	}
	public PhoneBuilder setRAM(int rAM) {
		this.RAM = rAM;
		return this;
	}
	public PhoneBuilder setBrand(String brand) {
		this.brand = brand;
		return this;
	}
	public PhoneBuilder setScreenSize(double screenSize) {
		this.screenSize = screenSize;
		return this;
	}
	public PhoneBuilder setBattery(int battery) {
		this.battery = battery;
		return this;
	}
	
	public Phone getPhone(){
		return new Phone(OS, RAM, brand, screenSize, battery);
		
	}
	
	
	

}
