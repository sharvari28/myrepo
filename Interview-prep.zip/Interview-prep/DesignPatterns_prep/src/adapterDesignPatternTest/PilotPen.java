package adapterDesignPatternTest;

public class PilotPen {

	public void mark(String str) {

	}

}
