package adapterDesignPatternTest;

public interface Pen {
	
	void write(String str);

}
