package adapterDesignPatternTest;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class TestNew extends Thread {

static int[][] matrix;
static int total;

public static void main(String[] args) throws IOException {

BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
String[] strs = br.readLine().trim().split("\\s+");
int N = Integer.parseInt(strs[0]);
int K = Integer.parseInt(strs[1]);

matrix = new int[N][N];
total = N * N;
while (K-- > 0) {
strs = br.readLine().trim().split("\\s+");
int i = Integer.parseInt(strs[0]);
int j = Integer.parseInt(strs[1]);
System.out.println(solve(N, i, j) + " ");
}

}

static int solve(int n, int i, int j) {
int[][] newMatrix = new int[n][n];
newMatrix = matrix;
int count = 0;
i = i - 1;
j = j - 1;
for (int k = 0; k < n; k++) {
for (int l = 0; l < n; l++) {
if (k == i || l == j) {
if (newMatrix[k][l] == 0) {
newMatrix[k][l] = 1;
++count;

}

}
}
}
matrix = newMatrix;
total = total - count;
return total;
}

}

