package adapterDesignPatternTest;

import java.io.*; 
import java.util.*; 
import java.lang.*; 
  
class CGF 
{ 
      
// Function count 
// the operations 
static String reduceString(String s){
	String right=s.substring(0,s.length()/2);
	int rightLength=right.length()-1;
	
	String left=s.substring(s.length()/2,s.length());
	int startIndex=0;
	char lastchar;
	
	for(int i=right.length()-1;i>0;){
		lastchar=right.charAt(rightLength);
		if(left.charAt(startIndex)==lastchar){
			while(left.charAt(startIndex)==lastchar){
				startIndex++;
			}
			
			while(right.charAt(i)==lastchar){
				rightLength--;
				i--;
			}
		}else break;
	}
	
	return right.substring(0, rightLength+1) + left.substring(startIndex);
	
} 
  
// Driver Code 
public static void main(String[] args) 
{ 
	
	Scanner scan=new Scanner(System.in);
	 String s = scan.nextLine(); 
      
    System.out.print(reduceString(s) + "\n"); 
} 
} 
