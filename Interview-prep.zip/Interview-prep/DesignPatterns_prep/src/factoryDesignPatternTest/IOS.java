package factoryDesignPatternTest;

public class IOS implements OS {

	@Override
	public void specifications() {
		
		System.out.println("Best OS is IOS");

	}

}
