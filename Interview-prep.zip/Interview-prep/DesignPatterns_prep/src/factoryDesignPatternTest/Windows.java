package factoryDesignPatternTest;

public class Windows implements OS {

	@Override
	public void specifications() {
		
		System.out.println("Best OS is WINDOWS");
	}

}
