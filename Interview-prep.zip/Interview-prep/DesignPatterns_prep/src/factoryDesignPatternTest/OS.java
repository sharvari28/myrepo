package factoryDesignPatternTest;

public interface OS {
	
	void specifications();

}
