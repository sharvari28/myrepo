package factoryDesignPatternTest;

public class FactoryMain {

	public static void main(String[] args) {
		
		/*OS obj = new Android();
		obj.specifications();*///---not a good way as we are exposing the class to everyone 
		                          //hence we create a factory class and return OS 

		
		OSFactory osf = new OSFactory();
		OS obj = osf.getInstance("other");
		obj.specifications();
	}

}
