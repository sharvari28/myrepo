package factoryDesignPatternTest;

public class Android implements OS {

	@Override
	public void specifications() {
		
		System.out.println("Best OS is ANDROID");
	}

}
