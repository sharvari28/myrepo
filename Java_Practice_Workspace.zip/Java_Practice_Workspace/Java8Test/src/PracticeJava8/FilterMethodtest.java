package PracticeJava8;

import java.util.Arrays;
import java.util.List;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.stream.Stream;

public class FilterMethodtest {

	public static void main(String[] args) {

		List<Integer> list = Arrays.asList(12, 20, 35, 46, 55, 68, 75);
//i want to add all elements divisible by 5
	//Method 1 --- using for loop
		int result=0;
		for(int i : list){
			if(i%5==0){
				result=result+i;
				
			}
		}
		System.out.println(result);
		
	//Method 2 --- using stream
		list.stream()
		    .filter(i -> i%5==0)
		    .reduce(0,Integer::sum);
		 
				}
	

}

