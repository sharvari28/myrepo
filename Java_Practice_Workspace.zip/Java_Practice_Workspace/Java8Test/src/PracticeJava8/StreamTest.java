package PracticeJava8;

import java.util.Arrays;
import java.util.List;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.stream.Stream;

public class StreamTest {

	public static void main(String[] args) {

		List<Integer> list = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9);

		/*int result = 0;

		for (int i : list) {
			result = result + i;
		}*/
		/**********************understanding map and reduce in detail**********/
		//System.out.println(list.stream().map(i -> i*2).reduce(0,(c,e) -> c+e));
		
		/*Function<Integer,Integer> f = new Function<Integer,Integer>(){

			@Override
			public Integer apply(Integer i) {
				
				return i*2;
			}
			
		};
		
		BinaryOperator<Integer> b = new BinaryOperator<Integer>(){

			@Override
			public Integer apply(Integer i, Integer j) {
				
				return i+j;
			}
			
		};
		Stream s = list.stream();
		Stream s1=s.map(f);
		// s1.forEach(System.out::println);
		 Integer s2=(Integer) s1.reduce(0,b);
		 System.out.println(s2);*/
/**********************************************************************************************************/		 
		 
		System.out.println(list.stream().map(i -> i*2).reduce(0,(c,e) -> c+e));  //can use this or can call sum method of Integer class
		 System.out.println(list.stream().map(i -> i*2).reduce(0,(c,e) -> Integer.sum(c, e)));
		 System.out.println(list.stream().map(i -> i*2).reduce(0,Integer::sum));//can use method reference as well
		 
				}
	

}
