package PracticeJava8;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class PredicateInterface {
	
	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(12, 20, 35, 46, 55, 68, 75);
		
		Predicate<Integer> predicate = new Predicate<Integer>(){

			@Override
			public boolean test(Integer i) {
				
				return i%5==0;
			}
			
		};
		
		System.out.println(list.stream()
				               .filter(predicate)
				               .reduce(0,Integer::sum));
/**************************************************************************************/
		//Map//findFirst//orElse
		System.out.println(list.stream()
	               .filter(i -> i%5==0)
	               .map(i -> i*2)
	               .reduce(0,Integer::sum));
		
		System.out.println(list.stream()
	               .filter(i -> i%5==0)
	               .map(i -> i*2)
	               .findFirst()
	               .orElse(0));
	}

}
