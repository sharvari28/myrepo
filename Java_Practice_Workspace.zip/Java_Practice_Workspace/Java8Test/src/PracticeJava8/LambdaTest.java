package PracticeJava8;

interface A{
	
	void show();
	default void abc(){
		System.out.println("abc");
	}
}

public class LambdaTest {
	
	public static void main(String[] args) {
		
	
	
 A a =() -> System.out.println("In show");
	
a.show();
a.abc();
}
}
