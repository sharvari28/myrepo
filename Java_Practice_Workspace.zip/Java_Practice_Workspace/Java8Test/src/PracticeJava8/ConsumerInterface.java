package PracticeJava8;

import java.util.ArrayList;
import java.util.function.Consumer;

public class ConsumerInterface {
	
	public static void main(String[] args) {
		
		ArrayList<Integer> list=new ArrayList<Integer>();
		list.add(2);
		list.add(3);
		list.add(10);
		list.add(15);
		list.add(27);
		
		/*Consumer<Integer> c = new Consumer<Integer>() {

			@Override
			public void accept(Integer i) {
				System.out.println(i);
			}
		};
		list.forEach(c);*/
	//Instead of above redundant code we can use lambda
		
		Consumer<Integer> c = (i) -> System.out.println(i);
		list.forEach(c);
		
		//or
		list.forEach((i) -> System.out.println(i));
		
	}

}
