package operationsOnArray;

public interface Driveable {
	void drive();

}

class car {
	Driveable d = new Driveable() {

		@Override
		public void drive() {
			System.out.println("anonymous inner class");

		}
	};
}



