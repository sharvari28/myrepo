package operationsOnArray;

public class Outer {

	private int i =100;
	
	public void show(){
		System.out.println("In outer class");
	}
	
	
	 class Inner{
		private int j=200;
		
		public void test(){
			System.out.println("In inner class");
			System.out.println("Outer class variable"+i);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Outer o = new Outer();
		o.show();
		
		Outer.Inner i = new Outer().new Inner();
		// Outer.Inner i = o.new Inner();--Alterntive
		i.test();

	}

}
