package operationsOnArray;

public class Outer2 {
	
	private int i = 100;
	public void test(){
		int j =200;
		System.out.println("test method"+ (i+j));
		
		class Inner{
			int k =300;
			public void testInner(){
				System.out.println("Class within method");
				System.out.println("Outer class variable" +i);
				System.out.println("Outer class variable" +j);
				System.out.println("Inner class variable" +k);
				
				Inner i = new Inner();
				i.testInner();
				
			}
		}
		
	}

	public static void main(String[] args) {
	Outer2 o2=new Outer2();
	o2.test();
	
	

	}

}
