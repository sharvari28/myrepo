package operationsOnArray;

public class BubbleSortTest {
	
	public void sort(int array[]){
		//BUBBLE SORT
		int temp;
		for(int i=0;i<array.length;i++){
			for(int j=0;j<array.length-1;j++){
				if (array[j]<array[j+1]){
					temp=array[j];
					array[j]=array[j+1];
					array[j+1]=temp;
				}
			}
		}
		
		for(int i=0;i<array.length;i++){
			System.out.println("Sorted array"+array[i]);
		}
	}


	public static void main(String[] args) {
		
		
		int array[]={22,76,3,56,345,2,6,23,99};
		BubbleSortTest b= new BubbleSortTest();
		b.sort(array);
	}

}
