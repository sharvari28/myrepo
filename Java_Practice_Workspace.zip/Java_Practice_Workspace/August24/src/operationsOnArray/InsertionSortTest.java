package operationsOnArray;

public class InsertionSortTest {

	public void ascsort(int array[]) {
		// ASCENDING
		System.out.println("*********************************ASCENDING********************************");
		System.out.println("Elements before sorting in ascending");
		for (int i = 0; i < array.length; i++) {
			System.out.println(array[i]);
		}

		int temp;
		int j;

		for (int i = 1; i < array.length; i++) {
			temp = array[i];
			for (j = i - 1; j >= 0 && array[j] > temp; j--) {
				array[j + 1] = array[j];
			}
			array[j + 1] = temp;
		}
		System.out.println("Elements after sorting in ascending");
		for (int i = 0; i < array.length; i++) {
			System.out.println(array[i]);
		}
	}

	public void descsort(int array[]) {
		// DESCENDING
		System.out.println("*********************************DESCENDING********************************");
		System.out.println("Elements before sorting in DESCENDING");
		for (int i = 0; i < array.length; i++) {
			System.out.println(array[i]);
		}

		int temp1;
		int j1;

		for (int i = 1; i < array.length; i++) {
			temp1 = array[i];
			for (j1 = i - 1; j1 >= 0 && array[j1] < temp1; j1--) {
				array[j1 + 1] = array[j1];
			}
			array[j1 + 1] = temp1;
		}
		System.out.println("Elements after sorting in DESCENDING");
		for (int i = 0; i < array.length; i++) {
			System.out.println(array[i]);
		}

	}

	public static void main(String[] args) {
		
		int array[] = { 12, 34, 64, 7856, 24, 556, 3423 };
		InsertionSortTest i = new InsertionSortTest();
		i.ascsort(array);
		i.descsort(array);

	}
}
