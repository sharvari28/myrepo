package operationsOnArray;
//*********************************STATIC INNER CLASS****************************************
public class Outer1 {
	
	private static int i =100;
	public void show(){
		System.out.println("In outer class");
	}
	
	static class Inner{
		private void test() {
			System.out.println("In inner class");
			System.out.println("Outer class member"+i);
		}
	}
	
	public static void main(String[] args) {
		
		Inner i = new Inner();
		i.test();
		
	}

}

