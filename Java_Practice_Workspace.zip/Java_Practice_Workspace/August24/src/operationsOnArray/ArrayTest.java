package operationsOnArray;
public class ArrayTest {
	int result = 0;
	
	public void first(int a) {
        System.out.println("Calling first method");
		
		result = result + a;
		System.out.println("Sum of given number is" + result);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int array[] = { 1, 2, 3, 4, 5 };
		ArrayTest at = new ArrayTest();
		for(int i=0;i<array.length;i++){
		at.first(array[i]);
		}

	}

}
