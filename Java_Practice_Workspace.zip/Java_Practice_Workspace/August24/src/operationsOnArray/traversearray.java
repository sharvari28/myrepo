package operationsOnArray;

import java.lang.reflect.Array;

public class traversearray {

	public void first(int a) {
        System.out.println("Calling first method to square single element");
		int result;
		result = a * a;
		System.out.println("Square of given number is" + result);
	}

	public void second(int array[]) {
		int sum = 0;
		for (int i = 0; i < array.length; i++) {
			sum = sum + array[i];
		}
		
		System.out.println("Sum of all elements in array is" + sum);
	}
	
	public void square(int array[]){
		int result;
		for(int i=0;i<array.length;i++){
			result=array[i]*array[i];
			System.out.println("Square is"+result);
		}
	}
	
	public void sort(int array[]){
		//BUBBLE SORT
		int temp;
		for(int i=0;i<array.length;i++){
			for(int j=0;j<array.length-1;j++){
				if (array[j]<array[j+1]){
					temp=array[j];
					array[j]=array[j+1];
					array[j+1]=temp;
				}
			}
		}
		
		for(int i=0;i<array.length;i++){
			System.out.println("Sorted array"+array[i]);
		}
	}

	public static void main(String[] args) {

		int array[] = { 1, 2, 3, 4, 5 };
		
		traversearray at = new traversearray();
		for(int i=0;i<array.length;i++){
		at.first(array[3]);
		}
		at.second(array);
		at.square(array);
		at.sort(array);

	}

}
