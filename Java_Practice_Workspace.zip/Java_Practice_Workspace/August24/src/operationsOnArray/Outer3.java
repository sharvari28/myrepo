package operationsOnArray;

public class Outer3 {
	
	class Ferrari{
		public void drive(){
			System.out.println("Ferrari");		
			}
	}
	
	class car{
		Ferrari p = new Ferrari();
	}

}
