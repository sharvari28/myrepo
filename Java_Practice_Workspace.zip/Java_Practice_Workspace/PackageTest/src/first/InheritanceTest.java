package first;

class Parent
{
	
	Parent()
	{
		System.out.println("Parent");
	}
	public void add()
	{
		int a=10;int b=20;
		System.out.println(a+b);
		
	}
}
class Child extends Parent
{
	Child ()
	{
	System.out.println("child");
	}
	}

class Child1 extends Parent
{
	Child1()
	{
	System.out.println("child1");
	}
	public void sub()
	{
		int a=20;int b=20;
		System.out.println(a-b);
		
	}
}



public class InheritanceTest {

	public static void main(String[] args) {
		
	Child c=new Child();
		c.add();
		
	Child1 c1 = new Child1();
	c1.sub();
		
		
		
	}

}
