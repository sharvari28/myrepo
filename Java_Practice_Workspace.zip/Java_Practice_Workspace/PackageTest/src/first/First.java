package first;

public class First {
public static int a=10;
public static int b=10;


public int num1=20;
public int num2=30;
	public static void main(String[] args) {
	System.out.println("fdgfdg");
	}

}
