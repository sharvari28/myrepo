package first;

public class ContainMent1 {

	
	int a=10;
	int  b=20;
	 public void show()
	{
		System.out.println("i am from show method");
	}
	
	public static void main(String[] args) {
		
		
	}

}
