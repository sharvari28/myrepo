//Multiple Iheritance not allowed in JAVA

/*package first;



class A{
	
}


class B{
	
}

class MultipleInheritanceTest extends A,B{
	
	

}



*/