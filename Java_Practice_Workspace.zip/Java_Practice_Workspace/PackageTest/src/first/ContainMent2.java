package first;

public class ContainMent2 {

	ContainMent1 c;
	String name;
	int id;

	public ContainMent2(ContainMent1 c, String name, int id) {
		super();
		this.c = c;
		this.name = name;
		this.id = id;
		System.out.println(id+name+c.a);
	}
	
	
	public void add()
	{
		System.out.println(c.a+c.b);
	}
public static void main(String[] args) {
		// TODO Auto-generated method stub

		 ContainMent2 c1=new  ContainMent2(new ContainMent1(),"pratik", 11);
		 c1.add();
		
		
		
	
	}

}
