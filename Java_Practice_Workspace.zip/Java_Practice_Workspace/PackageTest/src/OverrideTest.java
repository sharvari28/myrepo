class Samsung{
	public void Fm() {
		System.out.println("93.5");
	}
	
	public void Android() {
		System.out.println("OREO");
	}
	
	public void Camera() {
		System.out.println("12 MP");
		
	}
}

class SA50 extends Samsung{
	@Override
	public void Camera() {
		System.out.println("Override by 48 MP");
		
	}
}


public class OverrideTest {

	public static void main(String[] args) {
		SA50 S= new SA50();
		S.Android();
		S.Camera();
		S.Fm();
	}
}
