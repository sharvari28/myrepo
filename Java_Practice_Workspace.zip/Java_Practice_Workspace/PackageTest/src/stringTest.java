
public class stringTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String a = "abc";
		String b = "xyz";
		
		System.out.println(a);
		System.out.println(b);
		
		a="qwerty";
		b="asdf";
		
		System.out.println(a);
		System.out.println(b);
				
		

	}

}
