class a{
	a(int a){
		System.out.println("SUPER CONSTRUCTOR");
	}
}

class b extends a{
	b(){
		super(5);
		System.out.println("SUB CONSTRUCTOR");
		
	}
	
}
public class SupertestConstructor {
	public static void main(String[] args) {
		b B = new b();
	}
	
	
	

}
