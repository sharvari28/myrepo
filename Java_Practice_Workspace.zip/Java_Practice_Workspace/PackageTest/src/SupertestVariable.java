class NareshIT{
	int fees = 1000;
	String address = "HYD";
	String course = "JAVA NARESH IT";
	int duration = 100;
}


class Seed extends NareshIT{
	int fees = 10000;
	String address = "PUN";
	String course = "JAVA SEED IT";
	int duration = 101;
	
	public void info() {
		System.out.println("fees"+fees);
		System.out.println("address"+address);
		System.out.println("course"+course);
		System.out.println("duration"+duration);
		System.out.println("fees"+super.fees);
		System.out.println("address"+super.address);
		System.out.println("course"+super.course);
		System.out.println("duration"+super.duration);
	}
}
	

public class SupertestVariable {
	public static void main(String[] args) {
		Seed S = new Seed();
		S.info();
	}


}
