package second;

import first.First;

public class Second {

	public static void main(String[] args) {
		
		System.out.println(First.a+First.b);
		
		First f=new First();
System.out.println(f.num1+f.num2);
	}

}
