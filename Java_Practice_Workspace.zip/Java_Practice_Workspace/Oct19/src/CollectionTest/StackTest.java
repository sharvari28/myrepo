package CollectionTest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Stack;

public class StackTest {
	
	public static void main(String[] args) {
		Stack<Integer> a=new Stack<Integer>();
		a.push(20);
		a.push(30);
		a.push(40);
		a.push(50);
		a.pop();
		a.pop();
		
		//FILO(first in last out) -- pop deletes the latest element
		
		Collections.sort(a);
		
		for(Object x:a){
			System.out.println(x);
		}
		
		System.out.println("-----------------");
		
		a.forEach(System.out::println);//stream api
		
	}

}
