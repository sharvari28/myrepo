package CollectionTest;

import java.util.Set;
import java.util.TreeSet;

public class SetTest {
	public static void main(String[] args) {
		Set<Integer> a = new TreeSet<Integer>();

		// Cannot create object of set since its an interface. we create object
		// of Treeset which implements interface Set.
		a.add(10);
		a.add(20);
		a.add(30);
		a.add(10);
		a.add(20);
		a.add(30);
		//SET doesnot allow duplicates whereas list,stack allows duplicates.

		for (Object x : a) {
			System.out.println(x);
		}

		System.out.println("-----------------");

		a.forEach(System.out::println);// stream api

	}

}
