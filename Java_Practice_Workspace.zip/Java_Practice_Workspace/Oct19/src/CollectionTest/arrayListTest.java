package CollectionTest;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class arrayListTest {
//Same for arraylist and linked list
	private static final Object ABC = 55;

	public static void main(String[] args) {
		//We have to add generics in <> bracket.It can be integer, String, double etc.		
		List<Integer> a=new ArrayList<Integer>();
		a.add(10);
		a.add(20);
		//a.add(2.00004);
		a.add(40);
		//a.add("SHARVARI");
		//a.add(ABC);
		
		Collections.sort(a);
		
		Iterator<Integer> it=a.iterator();
		while(it.hasNext()){
			System.out.println(it.next());
		}
		
		//Iterator OR for each loop to access elements of collection
		
		
		for(Object x:a){
			System.out.println(x);
		}
		
		//In case of list we can use stream to access its object
		
		a.forEach(System.out::println);//streams api
	}

}
