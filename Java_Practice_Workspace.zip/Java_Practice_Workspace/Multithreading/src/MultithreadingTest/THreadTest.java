package MultithreadingTest;

class Count extends Thread {
	int count = 0;

	Count() {
		System.out.println("from constructor");
		this.start();

		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	public void run() {
		for (int i = 0; i <= 10; i++) {
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			System.out.println("count=" + count++);
		}
	}
}

public class THreadTest {

	public static void main(String[] args) {
		Count c = new Count();
		while (c.isAlive()) {
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			System.out.println("Thread is in alive state");
		}

		System.out.println("Thread is dead now");
		System.out.println("MainThread is also dead now");

	}

}
