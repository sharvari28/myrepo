package MultithreadingTest;

class Test1 {
	public synchronized void start(Test2 t2) {
		System.out.println("from test1 start method    1");
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		t2.stop();
	}

	public synchronized void stop() {
		System.out.println("from test 1 stop method");
	}
}

class Test2 {
	public synchronized void start(Test1 t1) {
		System.out.println("from test2 start method    2");
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		t1.stop();

	}

	public synchronized void stop() {
		System.out.println("from test 1 stop method");
	}
}

public class LockTest {

	public static void main(String[] args) {
		Test1 t1 = new Test1();
		Test2 t2 = new Test2();

		Thread thread1 = new Thread(() -> {
			int i = 0;
			while (i < 5) {
				t1.start(t2);
				try {
					Thread.sleep(1500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				i++;
			}
		});
		Thread thread2 = new Thread(() -> {
			int i = 0;
			while (i < 5) {
				t2.start(t1);
				try {
					Thread.sleep(1500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				i++;
			}
		});

		thread1.start();
		thread2.start();
	}

}
