package MultithreadingTest;


class TicketAvailability{
	int availableTickets=5;
	public synchronized void booking(String Name, int seats){

		if((availableTickets>seats)&&(seats!=0)){
			System.out.println(Name+ "your tickets has been booked");
			availableTickets=availableTickets-seats;
		}else{
			System.out.println(Name+ "we cannot book your tickets");
			System.out.println("Only" +availableTickets+ "seats available");
		}
	}
}

class TicketsThread extends Thread{
	TicketAvailability tcav;
	String PassengerName;
	int noofseats;
	TicketsThread(TicketAvailability tcav,String PassengerName,int noofseats){
		this.tcav=tcav;
		this.PassengerName=PassengerName;
		this.noofseats=noofseats;
	}
	public void run(){
		tcav.booking(PassengerName,noofseats);
	}
}
public class BusTest {

	public static void main(String[] args) {
		TicketAvailability ta=new TicketAvailability();
		TicketsThread ticket1=new TicketsThread(ta,"A",3);
		TicketsThread ticket2=new TicketsThread(ta,"B",3);
		
		ticket1.start();
		ticket2.start();

	}

}
