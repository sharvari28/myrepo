package Dec29;


class A{
	int num;
	boolean stop=false;
	public synchronized void set(int num){
		while(stop){
			try {
				wait();
			}catch(InterruptedException e){
				e.printStackTrace();
			}
		}
		this.num=num;
		System.out.println("set =" +num);
		stop=true;
		notify();
	}
	public synchronized void get()
	{
		while(!stop)
		{
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("get= "+num);
		stop=false;
		notify();
	}	
	
}

class Producer implements Runnable{

	A a;
	public Producer(A a){
		this.a=a;
		Thread t1=new Thread(this);
		t1.start();
	}
	@Override
	public void run() {
		for(int i=0;i<=10;i++){
			a.set(i);
			try{
				Thread.sleep(50);
			}catch(InterruptedException e){
				e.printStackTrace();
			}
		}
		
	}
	
}

class Consumer implements Runnable{

	A a;
	public Consumer(A a){
		this.a=a;
		Thread t1=new Thread(this);
		t1.start();
	}
	@Override
	public void run() {
		for(int i=0;i<=10;i++){
			a.get();
			try{
				Thread.sleep(500);
			}catch(InterruptedException e){
				e.printStackTrace();
			}
		}
		
	}
	
}

public class ThreadComm {

	public static void main(String[] args) {
		{
			A a=new A();
			Producer p=new Producer(a);
			Consumer c=new Consumer(a);

			}
	}

}
