package Dec29;

/*DigitalWatch program.
--------------------------------------*/


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;

import javax.swing.*;
public class digitalWatch implements Runnable{
static JFrame frame;
static JButton b1,b2,b3;
static int hours,minutes,seconds,mili;
String time="";
	digitalWatch()
	{
		
		frame =new JFrame("watch");
		

		Thread t1=new Thread(this);
		Thread t2=new Thread(this);
		b1=new JButton("start");
		b1.setBounds(40, 30,100,40);
		b3=new JButton("stop");
		b3.setBounds(180, 30,100,40);

		b2=new JButton();
		b2.setBounds(40, 100,150,40);
	
	b1.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {

			
			
		t1.start();
	
		}
	});
	
	b3.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
t1.stop();
		}
	});
	
	
		frame.add(b1);
		frame.add(b2);
		frame.add(b3);
		frame.setLayout(null);
         frame.setSize(300,400);
		frame.setVisible(true);
		
	}
	@Override
	public void run() {
	
		while(true)
		{
			Calendar cal=Calendar.getInstance();
			hours=cal.get(Calendar.HOUR_OF_DAY);
			minutes=cal.get(Calendar.MINUTE);
			seconds=cal.get(Calendar.SECOND);
			mili=cal.get(Calendar.MILLISECOND);
				
			b2.setText(hours+"  "+minutes+"  "+seconds+"  "+mili);
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public static void main(String[] args) {
	digitalWatch dw=new digitalWatch();
	




	}
	
	

}
