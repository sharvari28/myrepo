/*Counter:
------------------*/
package Dec29;

import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
public class Counter implements Runnable{
static JFrame f;
static JLabel l1,l2,l3;
static TextField t1,t2,t3;
static JButton b1,b2;


Counter()
{
	
	f=new JFrame("counter");
	
	l1=new JLabel("enter hours:");
	l1.setBounds(20, 20,120, 25);
	l2=new JLabel("enter minutes:");
	l2.setBounds(20,60,120, 25);

	t1=new TextField();
	t1.setBounds(160, 20,120, 25);
	t2=new TextField();
	t2.setBounds(160,60,120, 25);
	
	
	b1=new JButton("set");
	b1.setBounds(100, 150,100,40);
	
	b2=new JButton();
	b2.setBounds(100, 200,150,40);
	
	Thread t=new Thread(this);
b1.addActionListener(new ActionListener() {
	
	@Override
	public void actionPerformed(ActionEvent e) {
	t.start();
		
	}
});
	f.add(l1);
	f.add(l2);

f.add(t1);
	f.add(t2);

	f.add(b1);
	f.add(b2);
f.setLayout(null);
	f.setSize(400,400);
	f.setVisible(true);
	
}
	
	public static void main(String[] args) {
		Counter c=new Counter();
		
	}

	@Override
	public void run() {
		int hour=Integer.parseInt(t1.getText());
		int min=Integer.parseInt(t2.getText());
	for(int k=hour;k>=0;k--)
	{
	
	
	for(int j=min;j>=0;j--)
	{
	
	for(int i=59;i>=0;i--)
	{
		
		b2.setText(k+"  "+j+"  "+i);
		
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		}
	}
	min=59;

	
	}

		
	}
	

	}

}

