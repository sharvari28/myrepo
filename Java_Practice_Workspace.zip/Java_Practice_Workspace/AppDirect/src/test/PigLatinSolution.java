package test;

import java.util.*;
import java.lang.*;

class PigLatinSolution {

  // ---- Your solution goes here ---- //

  String translate(String phrase) {
	  
	   String vowel = "a,e,i,o,u";
	   String reverse = null;
	   String original=phrase;
	  int len = phrase.length();
	   if(phrase.contains(vowel)){
		   System.out.println("contain vowel");
	   }else{
		   
		   for(int i =len-1;i>0;i++){
			   reverse=reverse + original.charAt(1);
			   reverse.concat("ay");
			   System.out.println("Success" +reverse);
		   }
	   }
	   
    return reverse;
  }

  // ---- Driver (Main) - Entrypoint for tests ---- // 

  public static void main(String[] args) {
    PigLatinSolution kata = new PigLatinSolution();

     kata.c1__consonant();
}

void c1__consonant() {
    assertEquals(testCase(new Object() {}), "irdbay", translate("bird"));
  }

private void assertEquals(String testCase, String expected, String actual) {
    if (!Objects.equals(expected, actual)) {
      System.err.println("FAILED Test ".concat(testCase)
          .concat(" => [ Expected = \"").concat(expected)
          .concat("\", Actual = \"").concat(actual)
          .concat("\" ]"));
    } else {
      System.out.println("PASSED Test ".concat(testCase));
    }
  }

  private String testCase(Object o) {
    return o.getClass().getEnclosingMethod().getName();
  }
}
