package AnnotationTest;

import java.lang.annotation.Annotation;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
@Documented
@Inherited
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)

@interface seed{
	String cname();
	int fees();
}
	

@seed(cname = "JAVA", fees = 1000)
class Java{
	String cname;
	int fees;
	public Java(String cname,int fees){
		this.cname=cname;
		this.fees=fees;
	}
}

public class MyCustomAnnotationTest {

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void main(String[] args) {
		Java j=new Java("android",2000);
		Class c=j.getClass();
		Annotation an=c.getAnnotation(seed.class);
		
		seed s=(seed)an;
		System.out.println(s.cname());
		System.out.println(s.fees());

	}

}
