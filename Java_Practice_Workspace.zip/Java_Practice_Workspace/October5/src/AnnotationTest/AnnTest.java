package AnnotationTest;

class Parent{
	public void display(){
		System.out.println("PARENT CLASS DISPLAY");
	}
	@Deprecated
	public void show(){
		System.out.println("PARENT CLASS SHOW");
	}
}

class Child extends Parent{
	@Override
	public void display(){
		System.out.println("CHILD CLASS DISPLAY");
	}
	@Override
	public void show(){
		System.out.println("CHILD CLASS SHOW");
	}
	
}


public class AnnTest {

	public static void main(String[] args) {
		Child c = new Child();
		c.show();
		c.display();
		
		Parent p = new Parent();
		p.show();
		p.display();
		
	}
		

	}


