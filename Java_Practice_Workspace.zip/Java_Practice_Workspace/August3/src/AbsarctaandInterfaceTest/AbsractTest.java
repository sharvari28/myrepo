package AbsarctaandInterfaceTest;

abstract class MyShape {
	
	public abstract void area();

}

class circle extends MyShape{

	private int radius;
	double pi = 3.14;
	
	public circle(int i) {
		// TODO Auto-generated constructor stub
		radius=i;
	}

	@Override
	public void area() {
		// TODO Auto-generated method stub
		double Area = pi*radius*radius;
		System.out.println("Area of circle is" +Area);
		
		
	}
	
}

class rectangle extends MyShape{

	private int len,bred;
	
	public rectangle(int i, int j) {
		// TODO Auto-generated constructor stub
		len=i;
		bred=j;
	}

	@Override
	public void area() {
		// TODO Auto-generated method stub
		double Area = len*bred;
		System.out.println("Area of rectangle is" +Area);
	}
	
}


public class AbsractTest {
	public static void main(String[] args) {
		circle c = new circle(5);
		c.area();
		
		rectangle r = new rectangle(6,5);
		r.area();
		
		
	}

}
