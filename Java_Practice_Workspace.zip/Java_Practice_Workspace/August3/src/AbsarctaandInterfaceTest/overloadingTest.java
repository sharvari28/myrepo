package AbsarctaandInterfaceTest;

class Testoverloading{
	 public void add(double a,int b){
		  System.out.println("1st");
	 }
	 
	 public void add(float a,int b){
		 System.out.println("2nd");
	 }
	 
	 
}
public class overloadingTest {

	public static void main(String[] args) {

		Testoverloading t = new Testoverloading();
		t.add(1f, 1);
	}

}
