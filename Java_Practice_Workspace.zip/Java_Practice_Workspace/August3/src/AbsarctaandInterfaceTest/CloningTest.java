package AbsarctaandInterfaceTest;

public class CloningTest implements Cloneable{
	
	int id = 15;
	String name = "Pratik";
	
public static void main(String[] args) throws CloneNotSupportedException {
	
	CloningTest c = new CloningTest();
	CloningTest c1 = (CloningTest) c.clone();
	
	System.out.println(c.id+" "+c.name);
	
	
	c1.id= 45;
	c1.name= "sharvari";
	
	System.out.println(c1.id+" "+c1.name);
}
}
