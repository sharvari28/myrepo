package AbsarctaandInterfaceTest;


interface printable{
	
	public abstract void print();
}


class Test{
	public static void display(printable prn){
		prn.print();
	}
}

class employee1 implements printable{

	int id;
	String name;
	int salary;
	public employee1(int i, String string, int j) {
		// TODO Auto-generated constructor stub
		id = i;
		name = string;
		salary=j;
		
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println(id);
		System.out.println(name);
		System.out.println(salary);
		
		
	}
	
}
public class AbstractTest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		printable prn;
		
		employee1 e = new employee1(101,"JANE",20000);
		e.print();
		
		
		

	}

}
