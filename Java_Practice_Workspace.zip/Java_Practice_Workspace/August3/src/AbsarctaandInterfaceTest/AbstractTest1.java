package AbsarctaandInterfaceTest;

import java.util.Scanner;

abstract class Employee{
	public void info(){
		System.out.println("Name");
		Scanner scan = new Scanner(System.in);
		String Name=scan.next();
		System.out.println("Name is:"+Name);
		System.out.println("Surname");
		Scanner scan1 = new Scanner(System.in);
		String Surname=scan1.next();
		System.out.println("Surname is:"+Surname);
	}
	public abstract void privateinfo();
}

class survey extends Employee{

	@Override
	public void privateinfo() {
		// TODO Auto-generated method stub
		System.out.println("Salary");
		Scanner scan2 = new Scanner(System.in);
		int Salary=scan2.nextInt();
		System.out.println("Salary is:"+Salary);
		System.out.println("Age");
		Scanner scan3 = new Scanner(System.in);
		int Age=scan3.nextInt();
		System.out.println("Age is:"+Age);
	}
	
}
public class AbstractTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee E = new survey();//UPCASTING
		E.info();
		E.privateinfo();

	}

}
