package AbsarctaandInterfaceTest;

interface demo {
	public abstract void print();// ABSTRACT METHOD

	default void display() {
		System.out.println("DEFAULT DISPLAY");
	}

	static void show() {
		System.out.println("STATIC DISPLAY");
	}

}

interface demo2 {
	public abstract void print1();// ABSTRACT METHOD
	
}

class Child1 implements demo, demo2 {

	@Override
	public void print1() {
		// TODO Auto-generated method stub
		System.out.println("PRINT1--DEMO2");
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("PRINT--DEMO");
	}

}


public class InterfaceTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		demo d = new Child1();// CREATING OBJECT OF IMPLEMENTING CLASS
		d.display();
		d.print();
		demo.show();

		demo2 d2 = new Child1();// cannot create object of interface
		d2.print1();
		
	//call methods seperately using parent class reference or call all using child reference.	
		
		Child1 c1 = new Child1();
		c1.display();
		c1.print();
		c1.print1();
		
	}

}
