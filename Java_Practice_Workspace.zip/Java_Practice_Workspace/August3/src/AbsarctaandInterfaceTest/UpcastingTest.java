package AbsarctaandInterfaceTest;


class Parent{
	public void camera(){
		System.out.println("Parent class camera");
	}
	
	public void display(){
		System.out.println("Parent class display");
	}
}

class child extends Parent{
	@Override
	public void camera(){
		System.out.println("Child class camera");
	}
	
	public void show(){
		System.out.println("Child class show");
	}
}

public class UpcastingTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Parent P=new child();
		P.camera();
		P.display();
	
	child c = (child) new Parent();
	c.display();
	c.camera();
	c.show();//not possible

	}

}
