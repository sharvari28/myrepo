package AbsarctaandInterfaceTest;



interface demo3 {
	public abstract void print();// ABSTRACT METHOD

	

}

interface demo4 {
	public abstract void print1();// ABSTRACT METHOD
}




interface A extends  demo3,demo4{
	
}
public class InterfaceTest2 {

}
