package anonymousClasses;
public interface Driveable {
	void drive();

}

class test1{
	
	public static void call(Driveable d){
		d.drive();
	}
	public static void main(String[] args) {
		test1.call(new Driveable(){

			@Override
			public void drive() {
				// TODO Auto-generated method stub
				System.out.println("Drive Method");
				
			}});
			
		}
	}
	






