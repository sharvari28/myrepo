package anonymousClasses;

interface A {
	public void a();
	public void a1();
}

public class TestAnonymous {

	public static void main(String[] args) {
		A a = new A() {

			@Override
			public void a() {
				System.out.println("a");

			}

			@Override
			public void a1() {
				System.out.println("a1");
			}
		};
		a.a();
		a.a1();

	}
}
