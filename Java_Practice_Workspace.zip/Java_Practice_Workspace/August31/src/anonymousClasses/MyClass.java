package anonymousClasses;

interface bank {
	public void provideLoanInfo(); // abstract method
}// functional interface

class Hdfc implements bank {
	@Override
	public void provideLoanInfo() {
		System.out.println("This is HDFS bank");
		System.out.println("Provides loan at 10% ROI");
	}
}

class Sbi implements bank {
	@Override
	public void provideLoanInfo() {
		System.out.println("This is Sbi bank");
		System.out.println("Provides loan at 11% ROI");
	}
}

class Idbi implements bank {
	@Override
	public void provideLoanInfo() {
		System.out.println("This is Idbi bank");
		System.out.println("Provides loan at 12% ROI");
	}
}

public class MyClass {

	public void person(bank b) {
		b.provideLoanInfo();
	}

	public static void main(String[] args) {

		MyClass m = new MyClass();

		m.person(new Hdfc());
		m.person(new Sbi());
		m.person(new Idbi());

		m.person(new bank() {

			@Override
			public void provideLoanInfo() {
				System.out.println("This is Axis bank");
				System.out.println("Provides loan at 13% ROI");
			}
		});
		
		
		//Lambda--can be implented only for functional interface
		m.person(()->{
			System.out.println("This is Icici bank");
			System.out.println("Provides loan at 14% ROI");
		});
		
		//Lambda--
		bank b=()->{
			System.out.println("This is Citi bank");
			System.out.println("Provides loan at 15% ROI");
		};
		b.provideLoanInfo();
		}

	}

