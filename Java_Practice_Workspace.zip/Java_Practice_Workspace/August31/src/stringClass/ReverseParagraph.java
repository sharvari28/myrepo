package stringClass;

public class ReverseParagraph {
	
	public static void main(String[] args) {
		
		String Paragraph = "We can reverse each word of a string by the help of reverse(), "
				+ "split() and substring() methods. By using reverse() method of "
				+ "StringBuilder class, we can reverse given string. By the help of "
				+ "split method, we can get all words in an array. To get the first"
						+ " character, we can use substring() or charAt() method.";
		
		String[] p=Paragraph.split(" ");
		System.out.println(p.length);
		
		for(String word:p){
			System.out.println(word);
		}
				
	int len=Paragraph.length();
		System.out.println(len);
		
		for(int i=len-1;i>=0;i--){
			System.out.println(Paragraph.charAt(i));
		}
		
		
		
	}

}
