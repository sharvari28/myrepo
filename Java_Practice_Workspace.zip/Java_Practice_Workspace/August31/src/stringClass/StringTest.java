package stringClass;

public class StringTest {
	
	public static void main(String[] args) {
		String S1="SEED";
		String S2="SEED";
		String S3=new String("SEED");
		String S4=new String("SEED");
		
		if(S1==S2){
			System.out.println("S1 & S2 ARE EQUAL");
		}else{
			System.out.println("S1 & S2 ARE NOT-EQUAL");
		}
		
		if(S3==S4){
			System.out.println("S3 & S4 ARE EQUAL");
		}else{
			System.out.println("S3 & S4 ARE NOT-EQUAL");
		}
		
		if(S1.equals(S2)){
			System.out.println("S1 & S2 ARE EQUAL");
		}else{
			System.out.println("S1 & S2 ARE NOT-EQUAL");
		}
		
		if(S3.equals(S4)){
			System.out.println("S3 & S4 ARE EQUAL");
		}else{
			System.out.println("S3 & S4 ARE NOT-EQUAL");
		}
		
	}

}
