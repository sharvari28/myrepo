package stringClass;

public class ReverseString {

	public String reverse(String name) {
		int len = name.length();
		System.out.println(len);

		String rev = "";
		for (int i = (len - 1); i >= 0; i--) {
			rev = rev + name.charAt(i);
		}
		return rev;
	}

	public static void main(String[] args) {
		ReverseString s = new ReverseString();
		String s1 = "SHARVARI";
		String result = s.reverse(s1);
		System.out.println("Before reversing::" +s1);
		System.out.println("After reversing::" + result);
		System.out.println(s1.toLowerCase());
		System.out.println(s1.toUpperCase());
		System.out.println(s1.length());
		
		
		for(int i=0;i<s1.length();i++){
			System.out.println(s1.charAt(i));
		}
	}

}
