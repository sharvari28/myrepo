package MultithreadingTest;

import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
public class DigitalClock extends Thread{
	
	int hours=0;
	int minutes=0;
	int seconds=0;
	String time="";
	
	
	public void display(){
		time=hours+"-"+minutes+"-"+seconds;
		System.out.println(time);
	}
	
	public void run(){
		try{
			while(true){
				Calendar cal = Calendar.getInstance();
				hours=cal.get(Calendar.HOUR_OF_DAY);
				if(hours>12){
					hours-=12;
				}
				minutes=cal.get(Calendar.MINUTE);
				seconds=cal.get(Calendar.SECOND);
				
				display();
				
				Thread.sleep(500);
			}
		}
		
		catch(Exception e){
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {

		DigitalClock d=new DigitalClock();
		d.start();
	}

}
