package MultithreadingTest;

public class OddEvenTest {

	public static void main(String[] args) {

		Thread t1=new Thread(()->
		{
			for(int i=1;i<50;i++){
				if(i%2!=0){
					System.out.println(i);
					try {
						Thread.sleep(500);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		});
		
		
		Thread t2=new Thread(()->
		{
			for(int i=1;i<50;i++){
				if(i%2==0){
					System.out.println(i);
					try {
						Thread.sleep(500);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		});
		
		t1.start();
		t2.start();
		
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
