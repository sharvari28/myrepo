package Dec15;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileCopy {

	public static void main(String[] args) throws IOException {
		
		FileInputStream fis = new FileInputStream("D:\\First.txt");
		FileOutputStream fos = new FileOutputStream("D:\\FirstCopy.txt");
		
		
int data;
        
        while((data=fis.read())!=-1){
        	fos.write((char)data);
        }
        
        System.out.println("File copied successfully");
	}
	
	

}
