package Dec15;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class JavaSwingCalculator {

	public static void main(String[] args) {

		JFrame f = new JFrame("CALCULATOR");

		JLabel l1 = new JLabel("Enter first number");
		l1.setBounds(20, 20, 150, 40);
		f.add(l1);

		JLabel l2 = new JLabel("Enter second number");
		l2.setBounds(20, 80, 150, 40);
		f.add(l2);

		JLabel l3 = new JLabel("Result");
		l3.setBounds(20, 140, 150, 40);
		f.add(l3);

		JTextField t1 = new JTextField();
		t1.setBounds(160, 20, 150, 40);
		f.add(t1);

		JTextField t2 = new JTextField();
		t2.setBounds(160, 80, 150, 40);
		f.add(t2);

		JTextField t3 = new JTextField();
		t3.setBounds(160, 140, 150, 40);
		f.add(t3);

		JButton jb1 = new JButton("ADD");
		jb1.setBounds(40, 220, 70, 70);
		f.add(jb1);

		JButton jb2 = new JButton("SUB");
		jb2.setBounds(40, 290, 70, 70);
		f.add(jb2);

		JButton jb3 = new JButton("MUL");
		jb3.setBounds(120, 220, 70, 70);
		f.add(jb3);

		JButton jb4 = new JButton("DIV");
		jb4.setBounds(120, 290, 70, 70);
		f.add(jb4);


		

		JButton jb5 = new JButton("FACT");
		jb5.setBounds(200, 220, 70, 70);
		f.add(jb5);
		
		JButton jb6 = new JButton("DUMMY");
		jb6.setBounds(200, 220, 70, 70);
		f.add(jb6);
		
		
		jb1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				int num1 = Integer.parseInt(t1.getText());
				int num2 = Integer.parseInt(t2.getText());
				int result = num1 + num2;

				String r = String.valueOf(result);
				t3.setText(r);
			}
		});

		jb2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				int num1 = Integer.parseInt(t1.getText());
				int num2 = Integer.parseInt(t2.getText());
				int result = num1 - num2;

				String r = String.valueOf(result);
				t3.setText(r);
			}
		});

		jb3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				int num1 = Integer.parseInt(t1.getText());
				int num2 = Integer.parseInt(t2.getText());
				int result = num1 * num2;

				String r = String.valueOf(result);
				t3.setText(r);
			}
		});

		jb4.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				int num1 = Integer.parseInt(t1.getText());
				int num2 = Integer.parseInt(t2.getText());
				int result = num1 / num2;

				String r = String.valueOf(result);
				t3.setText(r);
			}
		});
		
		
		jb5.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {

				String s1=t1.getText();
				int fact=1;
				int num=Integer.parseInt(s1);
				
				for(int i=1;i<num;i++){
					fact=fact*i;
				}
				String r=String.valueOf(fact);
				t3.setText(r);
			}
		});

		f.setVisible(true);
		f.setLayout(null);
		f.setSize(400, 500);
	}

}
