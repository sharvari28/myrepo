package Dec15;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class FileWrite {

	public static void main(String[] args) throws IOException {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter file path to write");
		String filepath = sc.nextLine();
		FileOutputStream fos = new FileOutputStream(filepath);
		System.out.println("Enter string to write");
		String s1 = sc.nextLine();
		
		byte[] b = s1.getBytes();
		fos.write(b);
		
	}

}
