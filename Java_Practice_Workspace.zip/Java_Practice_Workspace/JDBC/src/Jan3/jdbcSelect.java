package Jan3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class jdbcSelect {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		Class.forName("oracle.jdbc.OracleDriver");//load and register driver
		
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "sql1_1", "sql1_1");
		// establish connection
		
		Statement st = con.createStatement();
		//create statement
		
		String q1="SELECT * FROM employees";
		//query
		
		ResultSet rs=st.executeQuery(q1);
		
		while(rs.next()){
			System.out.println(rs.getInt(1)+"  "+rs.getInt(2)+"  "+rs.getInt(3));			
		}
		con.close();
	}

}
