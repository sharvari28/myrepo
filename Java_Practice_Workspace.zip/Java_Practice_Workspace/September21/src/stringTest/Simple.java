package stringTest;


class A2{  
	  static{
		  System.out.println("static block is invoked");
		  }  
	  A2(){  
	   System.out.println("Hello main");  
	  }  {
		  System.out.println("Hello main"); 
	  }
	}  

public class Simple {

	public static void main(String[] args) {
		System.out.println("Hello World");
		int a=10;
		int b=20;
		
		System.out.println(a );
		System.out.println(b);
		
		a=a+b;
		b=a-b;
		a=a-b;
		
		System.out.println(a);
		System.out.println(b);
		
		
		A2 a2 = new A2();
		

	}

}
