//package stringTest;
//
//public class PalindromeTest {
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		
//		String palindrome = "MOM";
//		String reverse = "";
//		
//		int len = palindrome.length();
//		for()
//		
//
//	}
//
//}
