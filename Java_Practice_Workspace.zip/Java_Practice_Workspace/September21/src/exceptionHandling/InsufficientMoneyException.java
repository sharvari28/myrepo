package exceptionHandling;

public class InsufficientMoneyException extends Exception {
	InsufficientMoneyException(){
		System.out.println("InsufficientMoneyException::Get Money");
	}

}
