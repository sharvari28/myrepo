package exceptionHandling;

public class ChangeNotAvailableException extends Exception {

	ChangeNotAvailableException(){
		System.out.println("ChangeNotAvailableException::Get Change");
	}
}
