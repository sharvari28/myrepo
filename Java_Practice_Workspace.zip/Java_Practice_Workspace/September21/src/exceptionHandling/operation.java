package exceptionHandling;

public class operation{  
	 int data=50;  
	 String s="abc";
	  
	 void change(int data){  
	 data=data+100;//changes will be in the local variable only  
	 System.out.println(data);
	 }  
	     
	 public static void main(String args[]){  
	   operation op=new operation();  
	  
	   System.out.println("before change "+op.data);
	   
	   System.out.println("before change "+op.s);
	   op.change(100);  
	   System.out.println("after change "+op.data);
	   
	  
	 }  
	}  
