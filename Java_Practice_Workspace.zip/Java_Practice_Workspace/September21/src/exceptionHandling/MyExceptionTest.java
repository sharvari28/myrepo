package exceptionHandling;
import java.util.Scanner;

public class MyExceptionTest {
	
	public void payBill(int bill,int money) throws ChangeNotAvailableException
	{
		if(money>bill)
		{
			try
			{
			throw new ChangeNotAvailableException();
		}
			catch(ChangeNotAvailableException cn)
			{
				cn.getMessage();
			}
	}
		
		if(money<bill)
		{
			try
			{
				throw new InsufficientMoneyException();
			}
			catch(InsufficientMoneyException i)
			{
				i.getMessage();
			}
		}
	}

	@SuppressWarnings("resource")
	public static void main(String[] args) {
	
	{
		System.out.println("please enter the bill");
		int bill=new Scanner(System.in).nextInt();
		System.out.println("please enter the money");
		int money=new Scanner(System.in).nextInt();
		MyExceptionTest m=new MyExceptionTest();
	try {
		m.payBill(bill, money);
	} catch (ChangeNotAvailableException e) {
	
		e.printStackTrace();
	}

	}
	}
}