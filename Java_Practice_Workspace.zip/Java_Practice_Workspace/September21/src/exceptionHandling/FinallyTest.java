package exceptionHandling;

import java.util.Scanner;

public class FinallyTest {

	public static void main(String[] args) {
		
		try{
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter 1st number");
			int a=sc.nextInt();
			System.out.println("Enter 2nd number");
			int b=sc.nextInt();
			int result;
            result=a/b;
			System.out.println("result = "+result);
		}catch(ArrayIndexOutOfBoundsException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			System.out.println("will always be executed");
		}
	}

}
