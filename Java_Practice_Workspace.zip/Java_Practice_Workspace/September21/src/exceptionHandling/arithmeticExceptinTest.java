package exceptionHandling;

import java.util.Scanner;

public class arithmeticExceptinTest {

	public void test(){
		try{
			Scanner scan = new Scanner(System.in);
			System.out.println("Enter first num");
			int num1=scan.nextInt();
			System.out.println("Enter second num");
			int num2=scan.nextInt();
			int result;
			
			result=num1/num2;
			
			System.out.println("result = "+result);
			}catch(Exception e){
				e.printStackTrace();
			}
		finally{
			System.out.println("FINALLY");
		}
		
	}
	
	void display(){
		System.out.println("DISPLAY");
	}

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		arithmeticExceptinTest t = new arithmeticExceptinTest();
		t.test();
		t.display();

	}

}
