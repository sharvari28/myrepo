package exceptionHandling;

import java.io.FileReader;

public class FileNotFoundException {

	public static void main(String[] args) {
		FileReader reader = null;
		try{
			reader=new FileReader("C:/Users/statwaw/Desktop/server.log");
			System.out.println("File opened successfully");
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("Enter valid file path");
		}finally{
			try{
				reader.close();
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
	}
}
