package exceptionHandling;

import java.util.Scanner;

public class MultipleCatchTest {

	public static void main(String[] args) {
		
		try{
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the string");
			
			String name = sc.nextLine();
			System.out.println(name.length());
			int n=Integer.parseInt(name);
		}catch(NullPointerException|NumberFormatException e){
			System.out.println("String should not be empty and it should not be characters");
			e.printStackTrace();
		}

	}

}
