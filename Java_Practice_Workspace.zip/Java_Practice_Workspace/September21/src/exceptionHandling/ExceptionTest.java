package exceptionHandling;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ExceptionTest {

	public static void main(String[] args) {
		BufferedReader objReader = null;
		try {
			String s;

			objReader = new BufferedReader(new FileReader("C:/Users/statwaw/Desktop/SELF_STUDY/HIVE_QUERIES.txt"));
			while ((s = objReader.readLine()) != null) {
				System.out.println(s);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (objReader != null)
					objReader.close();
			} catch (IOException ex) {
				ex.printStackTrace();

			}

		}

	}
}