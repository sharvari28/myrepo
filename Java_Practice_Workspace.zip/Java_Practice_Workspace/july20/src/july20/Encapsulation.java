package july20;



class student{
	private int id;
	private String address;
	private String name;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
/*	public void setId(int id)
	{
		this.id=id;
	}
	public int getId()
	{
		return id;
	}*/
}


public class Encapsulation {

	public static void main(String[] args) {
	student s=new student();
	/*
		System.out.println(s.id);
		System.out.println(s.name);
		System.out.println(s.address);*/

		s.setId(11);
		System.out.println(s.getId());
		
		s.setName("pratik");
		System.out.println(s.getName());
		
		
		s.setAddress("pune");
		System.out.println(s.getAddress());

	}

}
