package july20;

public interface Test2 {

}
