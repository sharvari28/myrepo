package july20;

public enum EnumTest3 {

	HERO,HONDA,BAJAJ,ACTIVA,KTM,BULLET;
	public static void main(String args[])
	{
		
		for(EnumTest3 t:EnumTest3.values())
		{
			System.out.println(t);
		}
	}
	
	}
