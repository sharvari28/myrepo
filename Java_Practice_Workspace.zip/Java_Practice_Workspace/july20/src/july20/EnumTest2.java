package july20;


enum Bike
{
	HERO,HONDA,BAJAJ,ACTIVA,KTM,BULLET;


 
	public static void main(String[] args) {

		Bike e=Bike.BULLET;
		System.out.println(e);
		
		
		System.out.println(e.compareTo(Bike.HERO));
		int a=e.compareTo(Bike.BAJAJ);
		System.out.println(a);
	
		int a1=e.compareTo(Bike.HONDA);
		System.out.println(a1);

		int a3=e.compareTo(Bike.ACTIVA);
		System.out.println(a3);
		int a4=e.compareTo(Bike.BULLET);
		System.out.println(a4);
	
		int a5=e.compareTo(Bike.KTM);
		System.out.println(a5);
		Bike b=Bike.valueOf("KTM");
		
		System.out.println(b);
	}
}

