package july20;



class Test1 
{
	enum EnumTest {

		SUNDAY(100),MONDAY(200),TUESDAY(200,300),WEDNESDAY,THURSDAY,FRIDAY,SATURDAY;
	public static int a=10,b=20;
		private EnumTest()
		{
			System.out.println("hi i am constructor");
		}
		
		private EnumTest(int a)
		{
		System.out.println(a);	
		}
		private EnumTest(int a,int b)
		{
			System.out.println(a+b);
		}
		
		public void display()
		{
			System.out.println(a+b);
			System.out.println("helklo i am from dislpay method");
		}
		
		public static void show()
		{
			System.out.println("i am from show");
		}
	}
	
	
	
	
	public static void main(String[] args) {
		
		
		
EnumTest[] e=EnumTest.values();
	EnumTest e1=EnumTest.SATURDAY;
	System.out.println(e1.a+e1.b);
	
	e1.display();
		for(EnumTest et:e)
		{
			System.out.println(et+"==="+et.ordinal());
		}
		
		System.out.println(e1.valueOf(""));
		
	System.out.println(EnumTest.SUNDAY);
		System.out.println(EnumTest.MONDAY);
		
	}
	
}
	