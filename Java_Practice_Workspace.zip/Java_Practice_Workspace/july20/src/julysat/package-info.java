/**
 * 
 */
/**
 * @author syst
 *
 */
package julysat;