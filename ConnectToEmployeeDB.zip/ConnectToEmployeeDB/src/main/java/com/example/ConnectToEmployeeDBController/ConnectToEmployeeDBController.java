package com.example.ConnectToEmployeeDBController;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.properties.PropertyMapping;
import org.springframework.stereotype.Controller;
import org.xmlunit.util.Mapper;

import com.example.ConnectToEmployeeDBDTO.ConnectToEmployeeDBDTO;
import com.example.ConnectToEmployeeDBservice.serviceimpl;

@RestController
public class ConnectToEmployeeDBController {
	
	@Autowired
	private serviceimpl connecttoEmployeeserviceimpl;


	@GetMapping(value = "/employee")
	@ResponseBody
	public ConnectToEmployeeDBDTO getEmployee(@RequestBody String input){
		
		System.out.println("Json Object Received->" + input);
		long startTime = System.currentTimeMillis();
		
		ConnectToEmployeeDBDTO request = new ConnectToEmployeeDBDTO();
		ConnectToEmployeeDBDTO response = new ConnectToEmployeeDBDTO();
		
		response = connecttoEmployeeserviceimpl.core(request);
	}
	
	
	
	
}
