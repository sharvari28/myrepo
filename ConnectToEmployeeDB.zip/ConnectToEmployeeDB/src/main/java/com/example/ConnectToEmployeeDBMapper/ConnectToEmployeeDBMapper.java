package com.example.ConnectToEmployeeDBMapper;

import java.util.List;

import com.example.ConnectToEmployeeDBDTO.ConnectToEmployeeDBDTO;

public interface ConnectToEmployeeDBMapper {

	//public ConnectToEmployeeDBDTO fetchemployeedata(ConnectToEmployeeDBDTO connectToEmployeeDBDTOList);

	public ConnectToEmployeeDBDTO fetchemployeedata(ConnectToEmployeeDBDTO request);

}
