package com.example.ConnectToEmployeeDBservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.ConnectToEmployeeDBDTO.ConnectToEmployeeDBDTO;
import com.example.ConnectToEmployeeDBdao.dao;

public class serviceimpl {

	
	@Autowired
	dao connectToEmployeeDBdao;
	
	public ConnectToEmployeeDBDTO core(ConnectToEmployeeDBDTO request) throws Exception {
		ConnectToEmployeeDBDTO connectToEmployeeDBDTO = null;
		
		connectToEmployeeDBDTO = connectToEmployeeDBdao.fetchemployeedata(request);
		
		return connectToEmployeeDBDTO;
	
}
}
