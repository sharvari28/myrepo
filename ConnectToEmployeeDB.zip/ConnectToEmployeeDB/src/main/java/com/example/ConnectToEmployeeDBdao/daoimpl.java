package com.example.ConnectToEmployeeDBdao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.example.ConnectToEmployeeDBDTO.ConnectToEmployeeDBDTO;
import com.example.ConnectToEmployeeDBMapper.ConnectToEmployeeDBMapper;


public class daoimpl implements dao{

	@Autowired
	SqlSessionFactory mysqlSessionFactory;
	
	@Override
	public ConnectToEmployeeDBDTO fetchemployeedata(ConnectToEmployeeDBDTO request) {
System.out.println("Enter to fetchemployeedata method");
		
		ConnectToEmployeeDBDTO connectToEmployeeDBDTO = null;
		SqlSession sqlsession = null;
		ConnectToEmployeeDBMapper connectToEmployeeDBMapper = null;
		try (sqlsession = mysqlSessionFactory.openSession();){
			connectToEmployeeDBMapper = sqlsession.getMapper(ConnectToEmployeeDBMapper.class);
			connectToEmployeeDBDTO = connectToEmployeeDBMapper.fetchemployeedata(request);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e);
		} 
		System.out.println("Exit to fetchemployeedata method");
		
		return connectToEmployeeDBDTO;
	}

}
