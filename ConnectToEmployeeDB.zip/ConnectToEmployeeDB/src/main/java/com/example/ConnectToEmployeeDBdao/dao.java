package com.example.ConnectToEmployeeDBdao;

import java.util.List;

import com.example.ConnectToEmployeeDBDTO.ConnectToEmployeeDBDTO;

public interface dao {
	
	//ConnectToEmployeeDBDTO fetchemployeedata(ConnectToEmployeeDBDTO ConnectToEmployeeDBDTOList) ;

	ConnectToEmployeeDBDTO fetchemployeedata(ConnectToEmployeeDBDTO request);

}

